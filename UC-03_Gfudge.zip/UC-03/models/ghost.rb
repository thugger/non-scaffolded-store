class Ghost < ActiveRecord::Base
 # This Ghost class is linked to a ghosts table in the db.
end